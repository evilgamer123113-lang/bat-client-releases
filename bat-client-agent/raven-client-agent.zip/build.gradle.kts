import org.gradle.jvm.tasks.Jar

plugins {
    java
}

group = "com.raven"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.ow2.asm:asm:9.7.1")
    implementation("org.ow2.asm:asm-tree:9.7.1")
    testImplementation("org.ow2.asm:asm-util:9.7.1")
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

tasks.withType<JavaCompile> {
    options.release.set(8)
}

tasks.named<Jar>("jar") {
    manifest {
        attributes(
            "Premain-Class" to "com.raven.agent.AgentMain",
            "Agent-Class" to "com.raven.agent.AgentMain",
            "Can-Redefine-Classes" to "true",
            "Can-Retransform-Classes" to "true",
            "Implementation-Version" to project.version
        )
    }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) }) {
        exclude("META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA", "META-INF/MANIFEST.MF")
    }
}

val validateTransform by tasks.registering(JavaExec::class) {
    group = "verification"
    description = "Runs CapeTransformer against the real Loom-cached obfuscated jars."
    classpath = sourceSets.test.get().runtimeClasspath
    mainClass.set("com.raven.agent.TransformValidation")
    args(project.findProperty("tval") ?: "--scan")
}
