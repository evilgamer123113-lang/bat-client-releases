package com.raven.agent;

import java.util.HashMap;
import java.util.Map;

final class Mappings {
    static final int OFFICIAL = 0;
    static final int INTERMEDIARY = 1;
    static final int NAMED = 2;

    private final String version;
    private final int ns;
    private final Map<String, String[]> symbols = new HashMap<String, String[]>();
    private final Map<String, String> meta = new HashMap<String, String>();

    Mappings(String version, String mapping) {
        this.version = normalize(version);
        int ns;
        if ("official".equals(mapping)) ns = OFFICIAL;
        else if ("intermediary".equals(mapping)) ns = INTERMEDIARY;
        else if ("named".equals(mapping)) ns = NAMED;
        else throw new IllegalArgumentException("unknown mapping: " + mapping);
        this.ns = ns;
        for (String[] row : MappingsData.DATA) {
            if (!normalize(row[2]).equals(this.version)) continue;
            if ("X".equals(row[0])) {
                meta.put(row[1], row[3]);
            } else {
                symbols.put(row[0] + "/" + row[1], new String[] { row[3], row[4], row[5] });
            }
        }
    }

    String version() {
        return version;
    }

    String cls(String symbol) {
        String[] r = symbols.get("C/" + symbol);
        return r == null ? null : r[ns];
    }

    String mtd(String symbol) {
        String[] r = symbols.get("M/" + symbol);
        return r == null ? null : r[ns];
    }

    String meta(String key) {
        return meta.get(key);
    }

    boolean hasClass(String symbol) {
        return cls(symbol) != null;
    }

    private static String normalize(String v) {
        if (v == null) return "";
        if (v.endsWith(".0")) return normalize(v.substring(0, v.length() - 2));
        return v;
    }
}
