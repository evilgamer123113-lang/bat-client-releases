package com.raven.agent;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.instrument.Instrumentation;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Premain entry point. Expected agent args:
 *   version[,mapping]
 * e.g. "1.21.11,intermediary" for a Fabric launch, or "1.21.11,official" for
 * a vanilla launch. mapping defaults to "intermediary".
 */
public final class AgentMain {
    private static PrintWriter log;

    private AgentMain() {}

    private static void openLog() {
        try {
            String appData = System.getenv("APPDATA");
            if (appData != null) {
                File dir = new File(appData, "raven-client");
                dir.mkdirs();
                log = new PrintWriter(new FileWriter(new File(dir, "raven-cape-agent.log"), true));
            }
        } catch (Throwable ignored) {}
    }

    static void log(String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
        String line = "[" + ts + "] " + msg;
        System.out.println(line);
        if (log != null) { log.println(line); log.flush(); }
    }

    static void logErr(String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
        String line = "[" + ts + "] " + msg;
        System.err.println(line);
        if (log != null) { log.println(line); log.flush(); }
    }

    public static void premain(String args, Instrumentation inst) {
        openLog();
        log("[RavenCape] premain called args=" + args);
        String version = "";
        String mapping = "intermediary";
        if (args != null) {
            String[] parts = args.split(",");
            if (parts.length > 0) version = parts[0].trim();
            if (parts.length > 1) mapping = parts[1].trim();
        }
        log("[RavenCape] version=" + version + " mapping=" + mapping);
        try {
            Mappings mappings = new Mappings(version, mapping);
            log("[RavenCape] Mappings loaded, version=" + mappings.version());
            if (mappings.cls("CapeGetterOwner") == null || mappings.mtd("capeGetter") == null) {
                logErr("[RavenCape] unsupported version/mapping: " + version + "/" + mapping
                    + " CapeGetterOwner=" + mappings.cls("CapeGetterOwner")
                    + " capeGetter=" + mappings.mtd("capeGetter"));
                return;
            }
            log("[RavenCape] CapeGetterOwner=" + mappings.cls("CapeGetterOwner")
                + " capeGetter=" + mappings.mtd("capeGetter")
                + " Minecraft=" + mappings.cls("Minecraft")
                + " tick=" + mappings.mtd("tick"));
            CapeAnimator.init(mappings);
            inst.addTransformer(new CapeTransformer(mappings), false);
            log("[RavenCape] installed for MC " + mappings.version() + " (" + mapping + ")");
        } catch (Throwable t) {
            logErr("[RavenCape] agent init failed: " + t);
            t.printStackTrace();
        }
    }

    public static void agentmain(String args, Instrumentation inst) {
        premain(args, inst);
    }
}
