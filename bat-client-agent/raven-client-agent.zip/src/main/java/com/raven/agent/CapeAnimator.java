package com.raven.agent;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

import javax.imageio.ImageIO;

/**
 * Runtime for the animated cape. Runs inside the game JVM and talks to the
 * Minecraft classes purely through reflection, using names resolved from the
 * generated mapping table for the active MC version + mapping namespace.
 *
 * Loads %APPDATA%/raven-client/skins/cape-<name>-frame-*.png for a player,
 * builds a DynamicTexture, registers it with the game's TextureManager and
 * swaps it into the cape slot. Minecraft.tick drives the frame animation.
 */
public final class CapeAnimator {
    private static Mappings m;
    private static File skinsDir;
    private static final Map<String, AnimatedCape> CAPES = new ConcurrentHashMap<String, AnimatedCape>();
    private static final Set<String> NO_CAPE = ConcurrentHashMap.newKeySet();

    // resolved reflection handles
    private static Class<?> mcClass, tmClass, rlocClass, dynTexClass, nativeImageClass;
    private static Method mcInstance, getTextureManager, read, copyFrom, upload, getPixels;
    private static Method intArrGetter;
    private static boolean nativeBand;
    private static Constructor<?> dynTexCtor;
    private static Method fromNamespaceAndPath;
    private static Throwable resolveError;
    private static boolean resolved = false;

    // cached TextureManager internals for registration
    private static Field tmMapField;
    private static Object tmRef;
    private static boolean tmResolved = false;

    private CapeAnimator() {}

    public static void init(Mappings mappings) {
        m = mappings;
        String appData = System.getenv("APPDATA");
        if (appData != null) {
            skinsDir = new File(appData, "raven-client" + File.separator + "skins");
        }
    }

    // Hook for the cape getter (<1.20.2: getCloakTextureLocation).
    public static Object getCape(Object player, Object original) {
        try {
            String name = playerName(player);
            if (name == null) { AgentMain.log("[getCape] playerName=null"); return original; }
            AnimatedCape cape = capeFor(name, player.getClass().getClassLoader());
            if (cape == null) { AgentMain.log("[getCape] " + name + " no cape"); return original; }
            AgentMain.log("[getCape] " + name + " -> " + cape.location);
            return cape.location;
        } catch (Throwable t) {
            AgentMain.log("[getCape] EXCEPTION: " + t);
            return original;
        }
    }

    // Hook for getSkin (>=1.20.2): rebuild the immutable PlayerSkin record.
    public static Object getSkin(Object player, Object originalSkin) {
        try {
            if (originalSkin == null) return null;
            String name = playerName(player);
            if (name == null) return originalSkin;
            AnimatedCape cape = capeFor(name, player.getClass().getClassLoader());
            if (cape == null) return originalSkin;
            Object animatedCapeValue = cape.location;
            if (m.hasClass("ResourceTexture")) {
                Class<?> rt = Class.forName(m.cls("ResourceTexture"), false, player.getClass().getClassLoader());
                animatedCapeValue = rt.getConstructor(rlocClass).newInstance(cape.location);
            }
            System.out.println("[RavenCape] getSkin: player=" + name + " animatedCapeValueType=" + animatedCapeValue.getClass().getName() + " origSkinType=" + originalSkin.getClass().getName());
            Object result = rebuildPlayerSkin(originalSkin, animatedCapeValue, player.getClass().getClassLoader());
            System.out.println("[RavenCape] getSkin: rebuilt OK, resultType=" + result.getClass().getName());
            return result;
        } catch (Throwable t) {
            System.err.println("[RavenCape] getSkin failed: " + t);
            t.printStackTrace();
            return originalSkin;
        }
    }

    // Hook for Minecraft.tick.
    public static void tick() {
        try {
            long now = System.currentTimeMillis();
            for (AnimatedCape cape : CAPES.values()) {
                ensureRegistered(cape);
                cape.tick(now);
            }
        } catch (Throwable ignored) {}
    }

    // Re-asserts our DynamicTexture in the TextureManager map (survives reloads).
    private static void ensureRegistered(AnimatedCape cape) {
        try {
            if (!tmResolved) {
                Object mc = mcInstance.invoke(null);
                tmRef = getTextureManager.invoke(mc);
                tmMapField = findMapField(tmRef.getClass());
                tmResolved = true;
            }
            Map<Object, Object> map = (Map<Object, Object>) tmMapField.get(tmRef);
            if (map.get(cape.location) == cape.texture) return;
            map.put(cape.location, cape.texture);
        } catch (Throwable ignored) {}
    }

    // ---- player identity ----

    private static String playerName(Object player) throws Exception {
        for (Method md : player.getClass().getMethods()) {
            if (md.getParameterCount() == 0 && md.getReturnType().getName().equals("com.mojang.authlib.GameProfile")) {
                Object gp = md.invoke(player);
                if (gp == null) return null;
                try {
                    return (String) gp.getClass().getMethod("getName").invoke(gp);
                } catch (NoSuchMethodException e) {
                    return (String) gp.getClass().getMethod("name").invoke(gp);
                }
            }
        }
        return null;
    }

    // ---- animated cape lookup / creation ----

    private static AnimatedCape capeFor(String name, ClassLoader loader) throws Exception {
        String key = name.toLowerCase();
        AnimatedCape cape = CAPES.get(key);
        if (cape != null) return cape;
        if (NO_CAPE.contains(key)) { AgentMain.log("[capeFor] " + name + " in NO_CAPE"); return null; }
        File[] frames = findFrames(name);
        if (frames == null || frames.length < 2) {
            AgentMain.log("[capeFor] " + name + " no frames (found " + (frames == null ? 0 : frames.length) + ")");
            NO_CAPE.add(key);
            return null;
        }
        AgentMain.log("[capeFor] " + name + " frames=" + frames.length + " resolving handles...");
        resolveHandles(loader);
        if (resolveError != null) {
            AgentMain.log("[capeFor] resolve FAILED: " + resolveError);
            throw new Exception("reflection resolution failed", resolveError);
        }
        AgentMain.log("[capeFor] handles resolved OK. nativeBand=" + nativeBand + " dynTexCtor=" + dynTexCtor);

        List<Object> imgs = new ArrayList<Object>();
        try {
            for (File f : frames) {
                InputStream in = new FileInputStream(f);
                try {
                    imgs.add(read.invoke(null, in));
                } finally {
                    in.close();
                }
            }
            if (imgs.size() < 2) {
                closeImages(imgs);
                AgentMain.log("[capeFor] " + name + " only " + imgs.size() + " images loaded");
                return null;
            }
            AgentMain.log("[capeFor] loaded " + imgs.size() + " images, creating DynamicTexture...");
            Object first = imgs.get(0);
            Object texture;
            if (dynTexCtor.getParameterTypes().length == 2) {
                Supplier<String> nameSup = new Supplier<String>() {
                    public String get() { return "animated_cape"; }
                };
                texture = dynTexCtor.newInstance(nameSup, first);
            } else {
                texture = dynTexCtor.newInstance(first);
            }
            upload.invoke(texture);
            Object location = buildRloc(name);
            AgentMain.log("[capeFor] registering " + location + " ...");
            register(location, texture, loader);
            long[] delays = loadDelays(name, imgs.size());
            AnimatedCape built = new AnimatedCape(location, texture, imgs, delays);
            CAPES.put(key, built);
            AgentMain.log("[capeFor] " + name + " cape CREATED OK");
            return built;
        } catch (Throwable t) {
            AgentMain.log("[capeFor] EXCEPTION: " + t);
            closeImages(imgs);
            throw t;
        }
    }

    private static void closeImages(List<Object> imgs) {
        if (nativeImageClass == null) return;
        for (Object img : imgs) {
            try {
                nativeImageClass.getMethod("close").invoke(img);
            } catch (Throwable ignored) {}
        }
    }

    private static void register(Object location, Object texture, ClassLoader loader) throws Exception {
        Object mc = mcInstance.invoke(null);
        Object tm = getTextureManager.invoke(mc);
        Map<Object, Object> map = (Map<Object, Object>) findMapField(tm.getClass()).get(tm);
        map.put(location, texture);
        String regMsg = "registered " + location + " mapSize=" + map.size() + " verified=" + (map.get(location) == texture);
        System.out.println("[RavenCape] " + regMsg);
        AgentMain.log("[register] " + regMsg);
    }

    // Locates the TextureManager's internal map (ResourceLocation -> AbstractTexture).
    private static Field findMapField(Class<?> tmImplClass) throws Exception {
        Field fallback = null;
        for (Field f : tmImplClass.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (!Map.class.isAssignableFrom(f.getType())) continue;
            if (fallback == null) fallback = f;
            Type g = f.getGenericType();
            if (g instanceof ParameterizedType) {
                Type kt = ((ParameterizedType) g).getActualTypeArguments()[0];
                if (kt == rlocClass) {
                    f.setAccessible(true);
                    return f;
                }
            }
        }
        if (fallback == null) throw new IllegalStateException("no Map field in " + tmImplClass.getName());
        fallback.setAccessible(true);
        return fallback;
    }

    private static Object buildRloc(String name) throws Exception {
        String ns = "raven";
        String path = "animated_cape/" + safeName(name);
        if (fromNamespaceAndPath != null) return fromNamespaceAndPath.invoke(null, ns, path);
        return rlocClass.getConstructor(String.class, String.class).newInstance(ns, path);
    }

    // ---- PlayerSkin record rebuild ----

    private static Object rebuildPlayerSkin(Object skin, Object animatedCapeValue, ClassLoader loader) throws Exception {
        Class<?> skinClass = skin.getClass();
        Method getRC = Class.class.getMethod("getRecordComponents");
        Object[] comps = (Object[]) getRC.invoke(skinClass);
        Class<?> rcCls = Class.forName("java.lang.reflect.RecordComponent", false, loader);
        Method getAcc = rcCls.getMethod("getAccessor");
        Method getName = rcCls.getMethod("getName");
        String capeAccessor = m.mtd("capeAccessor");

        int n = comps.length;
        Object[] values = new Object[n];
        Class<?>[] types = new Class<?>[n];
        int capeIdx = -1;
        for (int i = 0; i < n; i++) {
            Method acc = (Method) getAcc.invoke(comps[i]);
            String cname = (String) getName.invoke(comps[i]);
            if (capeAccessor.equals(cname)) capeIdx = i;
            types[i] = acc.getReturnType();
            values[i] = acc.invoke(skin);
            System.out.println("[RavenCape]   comp[" + i + "] name=" + cname + " type=" + types[i].getName() + (i == capeIdx ? " <-- CAPE" : ""));
        }
        System.out.println("[RavenCape] rebuildPlayerSkin: " + n + " comps, capeIdx=" + capeIdx + " capeAccessor=" + capeAccessor + " animatedCapeValueType=" + animatedCapeValue.getClass().getName());
        if (capeIdx < 0) throw new IllegalStateException("cape component not found");
        values[capeIdx] = animatedCapeValue;
        Constructor<?> ctor = skinClass.getDeclaredConstructor(types);
        System.out.println("[RavenCape] rebuildPlayerSkin: ctor found=" + ctor);
        return ctor.newInstance(values);
    }

    // ---- reflection handles ----

    private static synchronized void resolveHandles(ClassLoader loader) throws Exception {
        if (resolved) return;
        resolved = true;
        try {
            mcClass = Class.forName(m.cls("Minecraft"), false, loader);
            tmClass = Class.forName(m.cls("TextureManager"), false, loader);
            rlocClass = Class.forName(m.cls("ResourceLocation"), false, loader);
            dynTexClass = Class.forName(m.cls("DynamicTexture"), false, loader);
            AgentMain.log("[resolve] classes OK: MC=" + mcClass.getName() + " TM=" + tmClass.getName() + " RL=" + rlocClass.getName() + " DT=" + dynTexClass.getName());

            nativeBand = m.hasClass("NativeImage");
            AgentMain.log("[resolve] nativeBand=" + nativeBand);
            if (nativeBand) {
                nativeImageClass = Class.forName(m.cls("NativeImage"), false, loader);
                read = findStatic(nativeImageClass, 1, nativeImageClass,
                        new Class<?>[] { InputStream.class });
                copyFrom = findInstance(nativeImageClass, 1, Void.TYPE,
                        new Class<?>[] { nativeImageClass });
                getPixels = findNamed(dynTexClass, m.mtd("getPixels"), 0, nativeImageClass, null);
            } else {
                read = ImageIO.class.getMethod("read", InputStream.class);
                intArrGetter = findInstance(dynTexClass, 0, int[].class, null);
                AgentMain.log("[resolve] int[] band: read=" + read + " intArrGetter=" + intArrGetter);
            }

            mcInstance = findStatic(mcClass, 0, mcClass, null);
            getTextureManager = findInstance(mcClass, 0, tmClass, null);
            upload = findNamed(dynTexClass, m.mtd("upload"), 0, Void.TYPE, null);
            AgentMain.log("[resolve] mcInstance=" + mcInstance + " getTM=" + getTextureManager + " upload=" + upload);

            String dynTexCtorMeta = m.meta("dynTexCtor");
            if (dynTexCtorMeta != null && dynTexCtorMeta.indexOf("Supplier") >= 0) {
                dynTexCtor = dynTexClass.getConstructor(Supplier.class, nativeImageClass);
            } else if ("BufferedImage".equals(dynTexCtorMeta)) {
                dynTexCtor = dynTexClass.getConstructor(BufferedImage.class);
            } else {
                dynTexCtor = dynTexClass.getConstructor(nativeImageClass);
            }
            AgentMain.log("[resolve] dynTexCtor=" + dynTexCtor + " meta=" + dynTexCtorMeta);

            if ("fromNamespaceAndPath".equals(m.meta("rlocCtor"))) {
                fromNamespaceAndPath = findStatic(rlocClass, 2, rlocClass,
                        new Class<?>[] { String.class, String.class });
            }
        } catch (Throwable t) {
            AgentMain.log("[resolve] FAILED: " + t);
            resolveError = t;
        }
    }

    private static Method findStatic(Class<?> clazz, int paramCount, Class<?> returnType, Class<?>[] params) {
        for (Method md : clazz.getDeclaredMethods()) {
            if (!Modifier.isStatic(md.getModifiers())) continue;
            if (matches(md, paramCount, returnType, params)) return md;
        }
        return null;
    }

    private static Method findInstance(Class<?> clazz, int paramCount, Class<?> returnType, Class<?>[] params) {
        for (Method md : clazz.getDeclaredMethods()) {
            if (Modifier.isStatic(md.getModifiers())) continue;
            if (matches(md, paramCount, returnType, params)) return md;
        }
        return null;
    }

    private static Method findNamed(Class<?> clazz, String name, int paramCount, Class<?> returnType, Class<?>[] params) {
        if (name == null) return null;
        for (Method md : clazz.getDeclaredMethods()) {
            if (!md.getName().equals(name)) continue;
            if (matches(md, paramCount, returnType, params)) return md;
        }
        return null;
    }

    private static boolean matches(Method md, int paramCount, Class<?> returnType, Class<?>[] params) {
        if (md.getParameterCount() != paramCount) return false;
        if (returnType != null && md.getReturnType() != returnType) return false;
        if (params != null) {
            Class<?>[] got = md.getParameterTypes();
            for (int i = 0; i < params.length; i++) {
                if (got[i] != params[i]) return false;
            }
        }
        return true;
    }

    // ---- files ----

    private static File[] findFrames(String playerName) {
        if (skinsDir == null || !skinsDir.isDirectory()) return null;
        final String prefix = "cape-" + playerName.toLowerCase() + "-frame-";
        File[] files = skinsDir.listFiles(new java.io.FileFilter() {
            public boolean accept(File f) {
                String lower = f.getName().toLowerCase();
                return lower.startsWith(prefix) && lower.endsWith(".png");
            }
        });
        if (files == null || files.length < 2) return null;
        Arrays.sort(files, new Comparator<File>() {
            public int compare(File a, File b) {
                return extractIndex(a.getName(), prefix) - extractIndex(b.getName(), prefix);
            }
        });
        return files;
    }

    private static int extractIndex(String name, String prefix) {
        String num = name.substring(prefix.length(), name.length() - 4);
        try {
            return Integer.parseInt(num);
        } catch (Exception e) {
            return Integer.MAX_VALUE;
        }
    }

    private static long[] loadDelays(String playerName, int count) {
        long[] delays = new long[count];
        for (int i = 0; i < count; i++) delays[i] = 120L;
        if (skinsDir == null) return delays;
        File meta = new File(skinsDir, "cape-" + playerName + ".json");
        if (meta.isFile()) {
            try {
                byte[] raw = java.nio.file.Files.readAllBytes(meta.toPath());
                String s = new String(raw, java.nio.charset.StandardCharsets.UTF_8);
                int a = s.indexOf('[');
                int b = s.lastIndexOf(']');
                if (a >= 0 && b > a) {
                    String[] parts = s.substring(a + 1, b).split(",");
                    for (int i = 0; i < Math.min(parts.length, count); i++) {
                        try {
                            long v = (long) Math.round(Double.parseDouble(parts[i].trim()));
                            if (v > 0) delays[i] = v;
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {}
        }
        return delays;
    }

    private static String safeName(String playerName) {
        StringBuilder sb = new StringBuilder();
        for (char c : playerName.toLowerCase().toCharArray()) {
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '.' || c == '-') sb.append(c);
            else sb.append('_');
        }
        return sb.toString();
    }

    // ---- per-player animated texture ----

    private static final class AnimatedCape {
        final Object location;
        final Object texture;
        final List<Object> frames;
        final long[] delays;
        int frame;
        long next;

        AnimatedCape(Object location, Object texture, List<Object> frames, long[] delays) {
            this.location = location;
            this.texture = texture;
            this.frames = frames;
            this.delays = delays;
            this.frame = 0;
            this.next = System.currentTimeMillis() + delays[0];
        }

        void tick(long now) {
            if (now < next || frames.size() < 2) return;
            frame = (frame + 1) % frames.size();
            next = now + delays[frame];
            try {
                if (nativeBand) {
                    Object pixels = getPixels.invoke(texture);
                    copyFrom.invoke(pixels, frames.get(frame));
                } else {
                    int[] px = (int[]) intArrGetter.invoke(texture);
                    BufferedImage img = (BufferedImage) frames.get(frame);
                    img.getRGB(0, 0, img.getWidth(), img.getHeight(), px, 0, img.getWidth());
                }
                upload.invoke(texture);
            } catch (Throwable ignored) {}
        }
    }
}
