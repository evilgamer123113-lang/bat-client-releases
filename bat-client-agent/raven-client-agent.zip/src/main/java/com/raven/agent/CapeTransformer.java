package com.raven.agent;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;

/**
 * Rewrites two methods at class-load time:
 *  - the cape getter on the player entity (getCloakTextureLocation / getSkin)
 *    so its result is handed to CapeAnimator, which substitutes the animated
 *    cape texture when frames exist for that player;
 *  - Minecraft.tick so CapeAnimator.tick() advances the animation frames.
 */
final class CapeTransformer implements ClassFileTransformer {
    private static final String HOOK = "com/raven/agent/CapeAnimator";

    private final String capeOwnerCls;
    private final String altCapeOwnerCls;
    private final String capeGetter;
    private final String capeReturnCls;
    private final String capeGetterDesc;
    private final String tickCls;
    private final String tick;
    private final boolean skinMode;

    CapeTransformer(Mappings m) {
        this.capeOwnerCls = m.cls("CapeGetterOwner");
        this.altCapeOwnerCls = m.cls("AbstractClientPlayer");
        this.capeGetter = m.mtd("capeGetter");
        this.skinMode = "PlayerSkin".equals(m.meta("capeGetterReturns"));
        this.capeReturnCls = skinMode ? m.cls("PlayerSkin") : m.cls("ResourceLocation");
        this.capeGetterDesc = "()L" + capeReturnCls + ";";
        this.tickCls = m.cls("Minecraft");
        this.tick = m.mtd("tick");
    }

    @Override
    public byte[] transform(ClassLoader loader, String className,
                            Class<?> classBeingRedefined, ProtectionDomain protectionDomain,
                            byte[] classfileBuffer) {
        if (className == null || classfileBuffer == null) return null;
        try {
            if (className.equals(capeOwnerCls) ||
                    (altCapeOwnerCls != null && className.equals(altCapeOwnerCls))) {
                return patchCapeGetter(classfileBuffer);
            }
            if (className.equals(tickCls)) {
                return patchTick(classfileBuffer);
            }
        } catch (Throwable t) {
            System.err.println("[RavenCape] transform failed for " + className + ": " + t);
        }
        return null;
    }

    private byte[] patchCapeGetter(byte[] classfileBuffer) {
        ClassNode cn = new ClassNode();
        new ClassReader(classfileBuffer).accept(cn, 0);
        MethodNode target = null;
        for (MethodNode mn : cn.methods) {
            if (mn.name.equals(capeGetter) && mn.desc.equals(capeGetterDesc)) {
                target = mn;
                break;
            }
        }
        if (target == null) return null;
        // No code to wrap: interface/abstract declaration, or a static getter.
        if ((target.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE | Opcodes.ACC_STATIC)) != 0) return null;

        String hookMethod = skinMode ? "getSkin" : "getCape";
        String hookDesc = "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;";
        String origName = capeGetter + "$raven$orig";

        // Rename the original implementation.
        target.name = origName;

        // Generate a fresh straight-line method with the original name. It has no
        // StackMapTable (no branches), so javac's unusual frames never interfere:
        //   this -> this -> raven$orig$getSkin(this) -> hook(this, ret) -> ret
        MethodNode wrapper = new MethodNode(target.access & ~Opcodes.ACC_ABSTRACT & ~Opcodes.ACC_NATIVE,
                capeGetter, capeGetterDesc, null, null);
        InsnList code = new InsnList();
        code.add(new VarInsnNode(Opcodes.ALOAD, 0));
        code.add(new VarInsnNode(Opcodes.ALOAD, 0));
        code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, cn.name, origName, capeGetterDesc, false));
        code.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOK, hookMethod, hookDesc, false));
        code.add(new TypeInsnNode(Opcodes.CHECKCAST, capeReturnCls));
        code.add(new InsnNode(Opcodes.ARETURN));
        wrapper.instructions.add(code);
        wrapper.maxStack = 3;
        wrapper.maxLocals = 1;
        cn.methods.add(wrapper);

        ClassWriter cw = new ClassWriter(0);
        cn.accept(cw);
        return cw.toByteArray();
    }

    private byte[] patchTick(byte[] classfileBuffer) {
        ClassNode cn = new ClassNode();
        new ClassReader(classfileBuffer).accept(cn, 0);
        MethodNode target = null;
        for (MethodNode mn : cn.methods) {
            if (mn.name.equals(tick) && mn.desc.equals("()V")) {
                target = mn;
                break;
            }
        }
        if (target == null) return null;

        InsnList patch = new InsnList();
        patch.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOK, "tick", "()V", false));
        if (target.instructions.size() == 0) {
            target.instructions.add(patch);
        } else {
            target.instructions.insert(patch);
        }

        ClassWriter cw = new ClassWriter(0);
        cn.accept(cw);
        return cw.toByteArray();
    }
}
