package com.raven.agent;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.util.CheckClassAdapter;

import java.io.File;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Headless validation: runs CapeTransformer against the real obfuscated jars
 * Loom cached, then runs ASM's CheckClassAdapter over the output to catch
 * malformed bytecode, and confirms each patch point actually fired.
 */
public final class TransformValidation {
    private static int pass = 0;
    private static int fail = 0;

    public static void main(String[] args) throws Exception {
        if (args.length == 0 || "--scan".equals(args[0])) {
            scan(new File(args.length > 1 ? args[1]
                    : "C:\\Users\\Noor-ul-Islam\\.gradle\\caches\\fabric-loom"));
        } else {
            one(args[0], args[1], args[2]);
        }
        System.out.println("RESULT pass=" + pass + " fail=" + fail);
        if (fail > 0) System.exit(1);
    }

    private static void scan(File loomRoot) {
        File[] dirs = loomRoot.listFiles(File::isDirectory);
        if (dirs == null) return;
        for (File dir : dirs) {
            File jar = new File(dir, "minecraft-merged.jar");
            if (!jar.isFile()) continue;
            String version = dir.getName();
            if (!tableHas(version)) {
                System.out.println("SKIP  " + version + " (not in mapping table)");
                continue;
            }
            one(version, jar.getAbsolutePath(), "official");
        }
    }

    private static boolean tableHas(String version) {
        for (String[] row : MappingsData.DATA) {
            if (row[2].equals(version)) return true;
        }
        return false;
    }

    private static void one(String version, String jarPath, String mapping) {
        try {
            Mappings m = new Mappings(version, mapping);
            CapeTransformer t = new CapeTransformer(m);
            JarFile jar = new JarFile(jarPath);
            String[] ownerCandidates = { m.cls("CapeGetterOwner"), m.cls("AbstractClientPlayer") };
            String tickCls = m.cls("Minecraft").replace('.', '/');

            byte[] tickBytes = read(jar, tickCls);
            if (tickBytes == null) throw new IllegalStateException(tickCls + " missing from jar");

            boolean ownerPatched = false;
            String patchedOwnerName = null;
            for (String candidate : ownerCandidates) {
                if (candidate == null) continue;
                String owner = candidate.replace('.', '/');
                byte[] ownerBytes = read(jar, owner);
                if (ownerBytes == null) continue;
                byte[] patchedOwner = t.transform(null, owner, null, null, ownerBytes);
                if (patchedOwner == null) continue;
                verify(patchedOwner, owner);
                assertHook(patchedOwner, owner, "getSkin", "getCape");
                ownerPatched = true;
                patchedOwnerName = owner;
            }
            if (!ownerPatched) throw new IllegalStateException("cape getter not patched");

            byte[] patchedTick = t.transform(null, tickCls, null, null, tickBytes);
            if (patchedTick == null) throw new IllegalStateException("tick not patched");
            verify(patchedTick, tickCls);
            assertHook(patchedTick, tickCls, "tick");
            System.out.println("PASS  " + version + " [" + mapping + "] " + patchedOwnerName + " + " + tickCls);
            pass++;
        } catch (Throwable e) {
            System.out.println("FAIL  " + version + " [" + mapping + "] " + e);
            fail++;
        }
    }

    private static byte[] read(JarFile jar, String name) throws Exception {
        JarEntry entry = jar.getJarEntry(name + ".class");
        if (entry == null) return null;
        java.io.InputStream in = jar.getInputStream(entry);
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    private static void verify(byte[] bytes, String name) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(0);
        PrintWriter pw = new PrintWriter(new java.io.StringWriter(), true);
        CheckClassAdapter cca = new CheckClassAdapter(cw, true);
        try {
            cr.accept(cca, 0);
        } catch (Throwable e) {
            throw new IllegalStateException("CheckClassAdapter rejected " + name + ": " + e, e);
        }
        if (cr.getAccess() < 0) throw new IllegalStateException(name + " bad access");
    }

    private static void assertHook(byte[] bytes, String className, String... hooks) {
        ClassNode cn = new ClassNode();
        new ClassReader(bytes).accept(cn, 0);
        int hits = 0;
        for (MethodNode mn : cn.methods) {
            for (AbstractInsnNode insn : mn.instructions) {
                if (insn.getOpcode() == Opcodes.INVOKESTATIC && insn instanceof MethodInsnNode) {
                    MethodInsnNode min = (MethodInsnNode) insn;
                    if (min.owner.equals("com/raven/agent/CapeAnimator")) {
                        for (String h : hooks) if (h != null && min.name.equals(h)) hits++;
                    }
                }
            }
        }
        if (hits == 0) throw new IllegalStateException("no CapeAnimator hook in " + className);
    }
}
